
let i = 0;
function contar(){
    let exibir = document.getElementById("a")
    i++
    exibir.innerHTML=i;

}
function limpar(){
    let exibir = document.getElementById("a")
    i=0
    exibir.innerHTML=i

}
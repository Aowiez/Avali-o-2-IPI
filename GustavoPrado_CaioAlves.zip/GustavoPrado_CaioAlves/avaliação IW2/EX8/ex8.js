


function soma() {
    let box1 = document.getElementById("txtn1");
    let box2 = document.getElementById("txtn2");
    let result = document.getElementById("res");
    let n1 = Number(box1.value);
    let n2 = Number(box2.value);
    let x= somar(n1,n2);
    result.innerHTML=x;
}

function somar(a, b) {
  return a + b;
}
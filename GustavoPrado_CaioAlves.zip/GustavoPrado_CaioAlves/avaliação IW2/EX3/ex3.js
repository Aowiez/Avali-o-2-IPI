window.onload = function () {
  //seleciona todas as tags div com esse id=box e organiza em vetores e para usar um especifico basta digitar o numero pela ordem q ele aparece iniciando do zero
  let boxes = document.querySelectorAll("div#box");
  boxes[4].innerHTML = "QuerySelectorAll";
  boxes[4].style.color = "white";

  //seleciona o primeiro id que aparece no documento com esse nome
  let porID = document.getElementById("box");
  porID.style.backgroundColor = "blue";
  porID.innerHTML="ById"

  //seleciona todos elementos com essa tag para especificar use como um vetor e especifique a ordem do elemento que deseja
  let porTAG = document.getElementsByTagName("div");
  porTAG[1].innerHTML = "Por tag ";

  //seleciona os elementos com a classe especificada 
    let porclass=document.getElementsByClassName("caixa");
    porclass[2].style.backgroundColor="green";
    porclass[2].innerHTML="ClassName"

    //seleciona o primeiro elemento que aparece 
    let box1=document.querySelector("div.caixa1");
    box1.innerHTML="QuerySelector"
};

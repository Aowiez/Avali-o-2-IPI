function all(){
    let exibir= document.getElementById("exibir");
    let text = document.getElementById("a");

        
    function upper(str){
       return str =text.toUpperCase();
    }
    let x = upper(text);
    exibir.innerHTML=x
}
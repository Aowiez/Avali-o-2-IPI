let a = window.document.getElementById("box");

//usando eventos

function clicou() {
  let a = window.document.getElementById("box");
  a.innerHTML = "Clicou";
  a.style.backgroundColor = "blue";
}
function entrar() {
  let a = window.document.getElementById("box");
  a.innerHTML = "entrou";
  a.style.backgroundColor = "purple";
}
function sair() {
  let a = window.document.getElementById("box");
  a.innerHTML = "saiu";
  a.style.backgroundColor = "green";
}

//com parametro
function parametro(){
    let n = document.getElementById("n");
    let n1=document.getElementById("n1");
    let y = quadrado(n1.value);
    n.innerHTML=y
    
    function quadrado(x) {
      return x * x;
    }
}
 

//nomeada






function soma(){
  let s1 =document.getElementById("s1");
let s2 =document.getElementById("s2");
let exibir1= document.getElementById("result");
  let fg = Number(s1.value)+Number(s2.value);
  exibir1.innerHTML=fg;
}

//construtora
function abre(){
  let c1 =document.getElementById("c1");
  let c2 =document.getElementById("c2");
  let exibir2= document.getElementById("result2");
  const sub = new Function('a','b', 'return a-b');
  exibir2.innerHTML=sub(Number(c1.value),Number(c2.value));
  
  
}

//literal
function parametro2(){
  let n = document.getElementById("nn");
  let n1=document.getElementById("nn1");
  let y = quadrado(n1.value);
  n.innerHTML=y
  
  function quadrado(x) {
    return x * x;
  }
}
//flecha

  function abre2(){
    let f1 =document.getElementById("f1");
    let f2 =document.getElementById("f2");
    let exibir3= document.getElementById("result3");
    
    let div = (x , y) => x / y;
    exibir3.innerHTML=div(Number(f1.value),Number(f2.value));

  }
